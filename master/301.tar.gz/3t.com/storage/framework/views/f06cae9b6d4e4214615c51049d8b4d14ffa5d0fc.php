<?php if($grid->allowPagination()): ?>
    <div class="box-footer d-block clearfix ">
        <?php echo $grid->paginator()->render(); ?>

    </div>
<?php endif; ?>
<?php /**PATH /www/wwwroot/3t.com/vendor/dcat/laravel-admin/src/../resources/views/grid/table-pagination.blade.php ENDPATH**/ ?>