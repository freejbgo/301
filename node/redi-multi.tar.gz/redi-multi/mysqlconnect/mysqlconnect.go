package mysqlconnect

import (
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
	"github.com/gookit/color"
	"time"
)

var (
	userName  string = "redi_admin"
	password  string = "WNKfdMyX4iLZ3XTH"
	ipAddrees string = "152.32.252.205"
	port      int    = 3306
	dbName    string = "redi_admin"
	charset   string = "utf8"
)

func ConnectMysql() *sqlx.DB {
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=%s", userName, password, ipAddrees, port, dbName, charset)
	Db, err := sqlx.Open("mysql", dsn)
	if err != nil {
		color.Greenf("[%v] mysql connect failed, detail is [%v]\n", time.Now().Format("2006-06-02 15:04:05"), err.Error())		
			//fmt.Printf("mysql connect failed, detail is [%v]", err.Error())
	}

	return Db
}
