package lagran

import (
	"context"
	"net"
	"redi-multi/config"
	"regexp"
	"sync"
	"time"

	"github.com/coreos/go-iptables/iptables"
	"github.com/florianl/go-nfqueue"
	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/panjf2000/ants/v2"
	"github.com/sirupsen/logrus"
)

const (
	windowSa uint16 = 1
	windowA  uint16 = 1
	windowPa uint16 = 1
	windowFa uint16 = 1
)

func Run() {
	if !Enabled() {
		logrus.Warn("[lagran] disabled (REDI_LAGRAN_DISABLED or lagran.enabled=false)")
		return
	}
	setIptable(config.LagranSport())
	var wg sync.WaitGroup
	if config.LagranBool("syn_ack", true) {
		p1, err := ants.NewPoolWithFunc(128, func(i interface{}) {
			packetHandle(i.(int))
			wg.Done()
		})
		if err != nil {
			logrus.Errorf("[lagran] syn_ack pool: %v", err)
			return
		}
		defer p1.Release()
		logrus.Debugln("[lagran] Starting Task p1")
		for i := 1000; i < 1128; i++ {
			wg.Add(1)
			_ = p1.Invoke(int(i))
		}
	}
	if config.LagranBool("ack", true) {
		p2, err := ants.NewPoolWithFunc(128, func(i interface{}) {
			packetHandle(i.(int))
			wg.Done()
		})
		if err != nil {
			logrus.Errorf("[lagran] ack pool: %v", err)
			return
		}
		defer p2.Release()
		logrus.Debugln("[lagran] Starting Task p2")
		for i := 2000; i < 2128; i++ {
			wg.Add(1)
			_ = p2.Invoke(int(i))
		}
	}
	if config.LagranBool("psh_ack", true) {
		p3, err := ants.NewPoolWithFunc(128, func(i interface{}) {
			packetHandle(i.(int))
			wg.Done()
		})
		if err != nil {
			logrus.Errorf("[lagran] psh_ack pool: %v", err)
			return
		}
		defer p3.Release()
		logrus.Debugln("[lagran] Starting Task p3")
		for i := 3000; i < 3128; i++ {
			wg.Add(1)
			_ = p3.Invoke(int(i))
		}
	}
	if config.LagranBool("fin_ack", true) {
		p4, err := ants.NewPoolWithFunc(128, func(i interface{}) {
			packetHandle(i.(int))
			wg.Done()
		})
		if err != nil {
			logrus.Errorf("[lagran] fin_ack pool: %v", err)
			return
		}
		defer p4.Release()
		logrus.Debugln("[lagran] Starting Task p4")
		for i := 4000; i < 4128; i++ {
			wg.Add(1)
			_ = p4.Invoke(int(i))
		}
	}
}

func setIptable(sport string) {
	logrus.Debugf("[lagran] sport:%s", sport)
	ipt, err := iptables.New()
	if err != nil {
		logrus.Errorf("[lagran] Iptabels new error:%v\n", err)
		return
	}

	// 仅追加本程序所需 NFQUEUE 规则，不再清空整个 OUTPUT 链，避免影响服务器其它出站策略
	if config.LagranBool("syn_ack", true) {
		err = ipt.AppendUnique("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "SYN,ACK", "-j", "NFQUEUE", "--queue-balance", "1000:1127")
		if err != nil {
			logrus.Errorf("[lagran] failed to set iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("ack", true) {
		err = ipt.AppendUnique("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "ACK", "-j", "NFQUEUE", "--queue-balance", "2000:2127")
		if err != nil {
			logrus.Errorf("[lagran] failed to set iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("psh_ack", true) {
		err = ipt.AppendUnique("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "PSH,ACK", "-j", "NFQUEUE", "--queue-balance", "3000:3127")
		if err != nil {
			logrus.Errorf("[lagran] failed to set iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("fin_ack", true) {
		err = ipt.AppendUnique("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "FIN,ACK", "-j", "NFQUEUE", "--queue-balance", "4000:4127")
		if err != nil {
			logrus.Errorf("[lagran] failed to set iptables OUTPUT chain, err: %v\n", err)
		}
	}
}
func UnsetIptable(sport string) {
	ipt, err := iptables.New()
	if err != nil {
		logrus.Errorf("[lagran] failed to new iptabels, err: %v\n", err)
		return
	}
	if config.LagranBool("syn_ack", true) {
		err = ipt.Delete("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "SYN,ACK", "-j", "NFQUEUE", "--queue-balance", "1000:1127")
		if err != nil {
			logrus.Errorf("[lagran] failed to delete iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("ack", true) {
		err = ipt.Delete("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "ACK", "-j", "NFQUEUE", "--queue-balance", "2000:2127")
		if err != nil {
			logrus.Errorf("[lagran] failed to delete iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("psh_ack", true) {
		err = ipt.Delete("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "PSH,ACK", "-j", "NFQUEUE", "--queue-balance", "3000:3127")
		if err != nil {
			logrus.Errorf("[lagran] failed to delete iptables OUTPUT chain, err: %v\n", err)
		}
	}
	if config.LagranBool("fin_ack", true) {
		err = ipt.Delete("filter", "OUTPUT", "-p", "tcp", "-m", "multiport", "--sport", sport, "--tcp-flags", "SYN,RST,ACK,FIN,PSH", "FIN,ACK", "-j", "NFQUEUE", "--queue-balance", "4000:4127")
		if err != nil {
			logrus.Errorf("[lagran] failed to delete iptables OUTPUT chain, err: %v\n", err)
		}
	}
}
func packetHandle(queueNum int) {
	nfqconfig := nfqueue.Config{
		NfQueue:      uint16(queueNum),
		MaxPacketLen: 0xFFFF,
		MaxQueueLen:  0xFF,
		Copymode:     nfqueue.NfQnlCopyPacket,
		WriteTimeout: 15 * time.Millisecond,
	}

	nf, err := nfqueue.Open(&nfqconfig)
	if err != nil {
		logrus.Errorf("[lagran] failed to open nfqueue socket queue=%d: %v", queueNum, err)
		return
	}

	defer nf.Close()

	ctx, cancelFunc := context.WithCancel(context.Background())
	defer cancelFunc()

	fn := func(a nfqueue.Attribute) int {
		id := *a.PacketID
		var srcIP net.IP
		var dstIP net.IP
		logrus.Debugf("[lagran] PKT[%03d]\t\n", id)

		packet := gopacket.NewPacket(*a.Payload, layers.LayerTypeIPv4, gopacket.Default)

		// Get the IP layer from this packet
		if ipLayer := packet.Layer(layers.LayerTypeIPv4); ipLayer != nil {
			// Get actual IP data from this layer
			ip, _ := ipLayer.(*layers.IPv4)
			srcIP = ip.SrcIP
			dstIP = ip.DstIP
			logrus.Debugf("[lagran] %15s > %-15s \n", srcIP, dstIP)
		}
		if tcpLayer := packet.Layer(layers.LayerTypeTCP); tcpLayer != nil {
			tcp, ok := tcpLayer.(*layers.TCP)
			if !ok || tcp == nil {
				_ = nf.SetVerdict(id, nfqueue.NfAccept)
				return 0
			}
			sportSet := config.LagranPortSet()
			reg := regexp.MustCompile(`\d+`)
			sport := reg.FindString(tcp.SrcPort.String())
			matchedPort := sport != "" && sportSet[sport]
			if matchedPort {
				var ok1 bool = config.LagranBool("syn_ack", true) && tcp.SYN && tcp.ACK
				var ok2 bool = config.LagranBool("ack", true) && tcp.ACK && !tcp.PSH && !tcp.FIN && !tcp.SYN && !tcp.RST
				var ok3 bool = config.LagranBool("psh_ack", true) && tcp.PSH && tcp.ACK
				var ok4 bool = config.LagranBool("fin_ack", true) && tcp.FIN && tcp.ACK
				var windowSize uint16
				if ok1 || ok2 || ok3 || ok4 {
					if ok1 {
						windowSize = windowSa
						logrus.Debugln("[lagran] Handle SYN=1 and ACK=1")
					}
					if ok2 {
						windowSize = windowA
						logrus.Debugln("[lagran] Handle ACK=1")
					}
					if ok3 {
						windowSize = windowPa
						logrus.Debugln("[lagran] Handle PSH=1 and ACK=1")
					}
					if ok4 {
						windowSize = windowFa
						logrus.Debugln("[lagran] Handle FIN=1 and ACK=1")
					}
					tcp.Window = windowSize
					err := tcp.SetNetworkLayerForChecksum(packet.NetworkLayer())
					if err != nil {
						logrus.Errorf("[lagran] failed to SetNetworkLayerForChecksum, err: %v\n", err)
					}
					buffer := gopacket.NewSerializeBuffer()
					options := gopacket.SerializeOptions{
						ComputeChecksums: true,
						FixLengths:       true,
					}
					if err := gopacket.SerializePacket(buffer, options, packet); err != nil {
						logrus.Errorf("[lagran] failed to SerializePacket, err: %v\n", err)
					}
					packetBytes := buffer.Bytes()
					logrus.Debugf("[lagran] Set TCP window size to %d\n", windowSize)
					err = nf.SetVerdictModPacket(id, nfqueue.NfAccept, packetBytes)
					if err != nil {
						logrus.Errorf("[lagran] failed to SetVerdictModified error: %v\n", err)
					}
					return 0
				}
				err := nf.SetVerdict(id, nfqueue.NfAccept)
				if err != nil {
					logrus.Errorf("[lagran] failed to SetVerdict, err: %v\n", err)
				}
				return 0
			}
			err := nf.SetVerdict(id, nfqueue.NfAccept)
			if err != nil {
				logrus.Errorf("[lagran] failed to SetVerdict, err: %v\n", err)
			}
			return 0
		}
		err := nf.SetVerdict(id, nfqueue.NfAccept)
		if err != nil {
			logrus.Errorf("[lagran] failed to SetVerdict, err: %v\n", err)
		}
		return 0
	}

	// Register your function to listen on nflqueue queue 100
	err = nf.RegisterWithErrorFunc(ctx, fn, func(e error) int {
		if e != nil {
			logrus.Errorf("[lagran] failed to RegisterWithErrorFunc, err: %v\n", e)
		}
		return 0
	})
	if err != nil {
		logrus.Errorf("[lagran] error: %v\n", err)
		return
	}
	<-ctx.Done()
}
