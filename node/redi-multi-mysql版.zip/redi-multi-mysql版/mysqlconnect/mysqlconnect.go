package mysqlconnect

import (
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

var (
	userName  string = "redi_admin"
	password  string = "WNKfdMyX4iLZ3XTH"
	ipAddrees string = "127.0.0.1"
	port      int    = 3306
	dbName    string = "redi_admin"
	charset   string = "utf8"
)

func ConnectMysql() *sqlx.DB {
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=%s", userName, password, ipAddrees, port, dbName, charset)
	Db, err := sqlx.Open("mysql", dsn)
	if err != nil {
		fmt.Printf("mysql connect failed, detail is [%v]", err.Error())
	}

	return Db
}
