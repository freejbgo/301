<?php

namespace App\Http\Middleware;

use App\Support\OpsDisplaySanitizer;
use Illuminate\Http\Middleware\TrustProxies as Middleware;
use Illuminate\Http\Request;

class TrustProxies extends Middleware
{
    /**
     * The trusted proxies for this application.
     *
     * @var array<int, string>|string|null
     */
    protected $proxies;

    public function __construct()
    {
        $raw = config('trustedproxy.proxies');
        if ($raw === '*' || $raw === '**') {
            $this->proxies = '*';
        } elseif ($raw === '' || $raw === null) {
            $this->proxies = null;
        } else {
            $parts = array_map('trim', explode(',', (string) $raw));
            $this->proxies = array_values(array_filter($parts, function (string $proxy): bool {
                return $proxy !== '' && ! OpsDisplaySanitizer::containsControlChars($proxy);
            }));
        }
    }

    /**
     * The headers that should be used to detect proxies.
     *
     * @var int
     */
    protected $headers =
        Request::HEADER_X_FORWARDED_FOR |
        Request::HEADER_X_FORWARDED_HOST |
        Request::HEADER_X_FORWARDED_PORT |
        Request::HEADER_X_FORWARDED_PROTO |
        Request::HEADER_X_FORWARDED_AWS_ELB;
}
