<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RediAcmeChallengeNodeSync;
use App\Models\RediCertDeployment;
use App\Models\RediDomainCert;
use App\Models\RediLagranSetting;
use App\Models\RediNode;
use App\Services\AcmeChallengeQuery;
use App\Services\CertificateDeployService;
use App\Services\DomainRecordNormalizer;
use App\Services\NodeAgentRevisionService;
use App\Support\OpsDisplaySanitizer;
use App\Support\RediAgentVersionGate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NodeAgentController extends Controller
{
    public function register(Request $request, CertificateDeployService $deployService)
    {
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');
        $this->persistAgentVersionIfPresent($request, $node);
        $node->last_heartbeat_at = now();
        $node->save();

        $deployService->syncDeploymentsForNode($node);

        return response()->json(['ok' => true, 'node_id' => $node->id]);
    }

    public function challengesSynced(Request $request)
    {
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');
        $rawDomains = $request->input('domains', []);
        if (! is_array($rawDomains)) {
            return response()->json(['message' => 'invalid domains'], 422);
        }
        $domains = array_slice($rawDomains, 0, 200);
        $allowed = AcmeChallengeQuery::ready()
            ->get(['domain_name', 'token', 'response_body'])
            ->filter(function ($row) {
                return AcmeChallengeQuery::nodePublishableRow($row->domain_name, $row->token, $row->response_body);
            })
            ->mapWithKeys(function ($row) {
                $domain = DomainRecordNormalizer::acmeHostKey((string) $row->domain_name);
                if ($domain === '') {
                    return [];
                }

                return [$domain => true];
            });
        $now = now();
        $synced = [];
        $ignored = 0;
        foreach ($domains as $raw) {
            if ($raw === null) {
                continue;
            }
            if (! is_string($raw)) {
                if (is_int($raw) || is_float($raw)) {
                    $raw = (string) $raw;
                } else {
                    $ignored++;
                    continue;
                }
            }
            if (OpsDisplaySanitizer::containsControlChars($raw)) {
                return response()->json([
                    'message' => 'invalid domain',
                    'domain' => OpsDisplaySanitizer::field($raw, '', 253),
                ], 422);
            }
            $domain = DomainRecordNormalizer::acmeHostKey($raw);
            if ($domain === '') {
                if (trim($raw) === '') {
                    continue;
                }

                return response()->json([
                    'message' => 'invalid domain',
                    'domain' => OpsDisplaySanitizer::field($raw, '', 253),
                ], 422);
            }
            if (! $allowed->has($domain)) {
                $ignored++;
                continue;
            }
            RediAcmeChallengeNodeSync::updateOrCreate(
                ['node_id' => $node->id, 'domain_name' => $domain],
                ['synced_at' => $now]
            );
            $synced[] = $domain;
        }

        if ($synced !== []) {
            $node->last_heartbeat_at = $now;
            $node->save();
        }

        return response()->json([
            'ok' => true,
            'synced' => $synced,
            'synced_count' => count($synced),
            'ignored_count' => $ignored,
        ]);
    }

    public function revision(Request $request, NodeAgentRevisionService $revisions, CertificateDeployService $deployService)
    {
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');

        $deployService->pruneStaleDeploymentsForNode($node);

        return response()->json($revisions->build($node));
    }

    public function lagran()
    {
        return response()->json([
            'lagran' => RediLagranSetting::current()->toAgentPayload(),
        ]);
    }

    public function heartbeat(Request $request, CertificateDeployService $deployService)
    {
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');
        $this->persistAgentVersionIfPresent($request, $node);
        $node->last_heartbeat_at = now();
        $node->save();

        $deployService->pruneStaleDeploymentsForNode($node);

        return response()->json(['ok' => true]);
    }

    protected function persistAgentVersionIfPresent(Request $request, RediNode $node): void
    {
        $input = $request->all();
        if (! array_key_exists('version', $input)) {
            return;
        }
        $version = RediAgentVersionGate::resolveFromInput($input);
        if ($version !== null) {
            $node->agent_version = $version;
        }
    }

    public function acmeChallenges()
    {
        $rows = AcmeChallengeQuery::ready()
            ->orderBy('id')
            ->get(['domain_name', 'token', 'response_body'])
            ->filter(function ($row) {
                return AcmeChallengeQuery::nodePublishableRow($row->domain_name, $row->token, $row->response_body);
            })
            ->map(function ($row) {
                $domain = DomainRecordNormalizer::acmeHostKey((string) $row->domain_name);
                if ($domain === '') {
                    return null;
                }

                return [
                    'domain_name' => $domain,
                    'token' => $row->token,
                    'response_body' => $row->response_body,
                ];
            })
            ->filter()
            ->filter(function ($row) {
                return AcmeChallengeQuery::nodePublishableRow(
                    $row['domain_name'] ?? null,
                    $row['token'] ?? null,
                    $row['response_body'] ?? null
                );
            })
            ->values();

        return response()->json(['challenges' => $rows]);
    }

    public function certificates(Request $request, CertificateDeployService $deployService)
    {
        // 空列表会使 Agent 清空内存证书：仅返回本节点仍有部署行且可拉取的证（含 status=ok，便于节点重启后恢复）。
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');

        $deployService->pruneStaleDeploymentsForNode($node);

        $certs = RediDomainCert::query()
            ->with('domain')
            ->whereHas('deployments', function ($query) use ($node) {
                $query->where('node_id', $node->id);
            })
            ->where(function ($query) {
                $query->whereIn('status', [
                    RediDomainCert::STATUS_ISSUED,
                    RediDomainCert::STATUS_DEPLOYING,
                    RediDomainCert::STATUS_ACTIVE,
                ])->orWhere(function ($inner) {
                    $inner->where('status', RediDomainCert::STATUS_VALIDATING)
                        ->whereNotNull('certificate')
                        ->where('certificate', '!=', '');
                });
            })
            ->whereHas('domain', function ($query) {
                $query->where('status', 1);
            })
            ->orderBy('id')
            ->get();

        $payload = [];
        foreach ($certs as $cert) {
            if (! CertificateDeployService::certIsNodePullable($cert)) {
                if (DomainRecordNormalizer::certMatchesAdminDomain($cert)
                    && ($cert->certificate || $cert->private_key)
                    && (! $cert->getCertificatePem() || ! $cert->getPrivateKeyPem())) {
                    $cert->flagCredentialUnreadableIfNeeded();
                }

                continue;
            }
            $cert = CertificateDeployService::freshCertWithPersistedRealign($cert);
            if (! $cert) {
                continue;
            }
            $pem = $cert->getCertificatePem();
            $key = $cert->getPrivateKeyPem();
            $host = DomainRecordNormalizer::acmeHostKey((string) $cert->domain_name);
            if ($host === '') {
                continue;
            }
            $payload[] = [
                'cert_id' => $cert->id,
                'domain' => $host,
                'certificate' => $pem,
                'private_key' => $key,
                'force_https' => (bool) optional($cert->domain)->force_https,
            ];
        }

        return response()->json(['certificates' => $payload]);
    }

    public function ack(Request $request, CertificateDeployService $deployService)
    {
        /** @var RediNode $node */
        $node = $request->attributes->get('redi_node');
        $certId = filter_var($request->input('cert_id'), FILTER_VALIDATE_INT);
        $ok = $request->boolean('ok', true);
        $error = $request->input('error');

        if ($request->has('error') && $error !== null && ! is_string($error)) {
            return response()->json(['message' => 'invalid error'], 422);
        }

        if ($certId === false || $certId < 1) {
            return response()->json(['message' => 'invalid cert_id'], 422);
        }

        if ($ok) {
            $error = null;
        }

        $cert = RediDomainCert::find($certId);
        if (! $cert) {
            return response()->json(['message' => 'cert not found'], 404);
        }

        $hasDeployment = RediCertDeployment::query()
            ->where('cert_id', $certId)
            ->where('node_id', $node->id)
            ->exists();
        if (! $hasDeployment) {
            return response()->json(['ok' => true, 'ignored' => true]);
        }

        if (is_string($error) && OpsDisplaySanitizer::containsControlChars($error)) {
            return response()->json([
                'message' => 'invalid error',
                'error' => OpsDisplaySanitizer::field($error, '', 500),
            ], 422);
        }

        $error = is_string($error) ? OpsDisplaySanitizer::logSnippet($error, 2000) : null;
        if ($error === '') {
            $error = null;
        }

        if (! $deployService->markNodeAck($cert, $node, $ok, $error)) {
            return response()->json(['message' => 'ack not applied'], 409);
        }

        return response()->json(['ok' => true]);
    }

    public function redirectRules()
    {
        $rows = DB::table('redi_admin_domain')
            ->where('status', 1)
            ->orderBy('id')
            ->get(['original_url', 'force_https'])
            ->map(function ($row) {
                $host = DomainRecordNormalizer::acmeHostKey((string) $row->original_url);
                if ($host === '') {
                    return null;
                }

                return [
                    'original_url' => $host,
                    'force_https' => (bool) $row->force_https,
                ];
            })
            ->filter()
            ->values();

        return response()->json(['rules' => $rows]);
    }
}
