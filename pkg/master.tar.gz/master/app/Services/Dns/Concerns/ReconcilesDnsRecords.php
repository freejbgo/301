<?php

namespace App\Services\Dns\Concerns;

use App\Support\RediErrorMessage;

use App\Models\RediNode;
use App\Support\HostNameValidator;
use App\Support\OpsDisplaySanitizer;

/**
 * 先增/改、后删，避免「先删后建」在 API 失败时把记录删光。
 *
 * @phpstan-type DnsRow array{id: string, value: string}
 */
trait ReconcilesDnsRecords
{
    /**
     * @param  DnsRow[]  $existing
     * @param  string[]  $desiredIps
     */
    protected function reconcileARecordValues(array $existing, array $desiredIps, callable $create, callable $deleteById): void
    {
        $desired = [];
        foreach (RediNode::filterValidIpv4List($desiredIps) as $ip) {
            $desired[strtolower($ip)] = $ip;
        }
        if ($desired === []) {
            throw new \RuntimeException(RediErrorMessage::get('dns.no_node_ips'));
        }

        $kept = [];
        $toDelete = [];
        foreach ($existing as $row) {
            $id = (string) ($row['id'] ?? '');
            $value = strtolower(rtrim(trim((string) ($row['value'] ?? '')), '.'));
            if ($id === '' || $value === '') {
                continue;
            }
            if (isset($desired[$value]) && ! isset($kept[$value])) {
                $kept[$value] = $id;
            } else {
                $toDelete[] = $id;
            }
        }

        foreach ($desired as $lower => $ip) {
            if (! isset($kept[$lower])) {
                $create($ip);
            }
        }

        $this->deleteDnsRecordIds($toDelete, $deleteById);
    }

    /**
     * @param  DnsRow[]  $existing
     * @param  string[]  $desiredIpv6s
     */
    protected function reconcileAAAARecordValues(array $existing, array $desiredIpv6s, callable $create, callable $deleteById): void
    {
        $desired = [];
        foreach ($desiredIpv6s as $ip) {
            $original = trim((string) $ip);
            if ($original === '') {
                continue;
            }
            if (! RediNode::isValidPublicIpv6($original)) {
                throw new \RuntimeException(RediErrorMessage::get('dns.pool_aaaa_invalid', ['value' => $original]));
            }
            $canonical = RediNode::canonicalPublicIpv6($original);
            $bytes = RediNode::ipv6ToBytes($canonical);
            if ($bytes === '') {
                throw new \RuntimeException(RediErrorMessage::get('dns.pool_aaaa_invalid', ['value' => $original]));
            }
            if (! isset($desired[$bytes])) {
                $desired[$bytes] = $canonical;
            }
        }

        if ($desired === []) {
            $toDelete = [];
            foreach ($existing as $row) {
                $id = (string) ($row['id'] ?? '');
                if ($id !== '') {
                    $toDelete[] = $id;
                }
            }
            $this->deleteDnsRecordIds($toDelete, $deleteById);

            return;
        }

        $kept = [];
        $toDelete = [];
        foreach ($existing as $row) {
            $id = (string) ($row['id'] ?? '');
            $value = trim(rtrim(trim((string) ($row['value'] ?? '')), '.'));
            if ($id === '' || $value === '') {
                continue;
            }
            $bytes = '';
            if (RediNode::isValidPublicIpv6($value)) {
                $canonical = RediNode::canonicalPublicIpv6($value);
                $bytes = RediNode::ipv6ToBytes($canonical);
            }
            if ($bytes !== '' && isset($desired[$bytes]) && ! isset($kept[$bytes])) {
                $kept[$bytes] = $id;
            } else {
                $toDelete[] = $id;
            }
        }

        foreach ($desired as $bytes => $canonical) {
            if (! isset($kept[$bytes])) {
                $create($canonical);
            }
        }

        $this->deleteDnsRecordIds($toDelete, $deleteById);
    }

    /**
     * @param  DnsRow[]  $existing
     */
    protected function reconcileCnameTarget(array $existing, string $targetFqdn, callable $create, callable $update, callable $deleteById): void
    {
        $target = HostNameValidator::toCanonicalAscii($targetFqdn);
        if ($target === '' || ! HostNameValidator::isValidHostLabel($target)) {
            throw new \RuntimeException(RediErrorMessage::get('dns.cname_target_invalid'));
        }
        $target = strtolower(rtrim($target, '.'));

        $keeperId = null;
        $toDelete = [];
        foreach ($existing as $row) {
            $id = (string) ($row['id'] ?? '');
            $value = strtolower(rtrim(trim((string) ($row['value'] ?? '')), '.'));
            if ($id === '') {
                continue;
            }
            if ($value === $target && $keeperId === null) {
                $keeperId = $id;
            } else {
                $toDelete[] = $id;
            }
        }

        if ($keeperId === null) {
            if ($existing !== []) {
                $firstId = (string) ($existing[0]['id'] ?? '');
                if ($firstId !== '') {
                    $update($firstId, $target);
                    $keeperId = $firstId;
                    for ($i = 1; $i < count($existing); $i++) {
                        $id = (string) ($existing[$i]['id'] ?? '');
                        if ($id !== '') {
                            $toDelete[] = $id;
                        }
                    }
                } else {
                    $create($target);
                }
            } else {
                $create($target);
            }
        }

        $ids = [];
        foreach (array_unique($toDelete) as $id) {
            if ($keeperId !== null && $id === $keeperId) {
                continue;
            }
            $ids[] = $id;
        }
        $this->deleteDnsRecordIds($ids, $deleteById);
    }

    /**
     * @param  string[]  $ids
     */
    protected function deleteDnsRecordIds(array $ids, callable $deleteById): void
    {
        $failed = [];
        foreach ($ids as $id) {
            try {
                $deleteById($id);
            } catch (\Throwable $e) {
                $failed[] = $id.': '.OpsDisplaySanitizer::logSnippet($e->getMessage(), 200);
            }
        }
        if ($failed !== []) {
            throw new \RuntimeException(RediErrorMessage::get('dns.delete_stale_failed', ['detail' => implode('; ', $failed)]));
        }
    }
}
