<?php

namespace App\Models;

use App\Services\CertificateDeployService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;
use App\Support\RediCertLastError;
use Illuminate\Support\Facades\Log;

class RediDomainCert extends Model
{
    /**
     * 租户归属通过关联域名 {@see RediAdminDomain}（及证书队列/部署路径上的 admin_id 校验）保证；
     * 本模型未使用 {@see \App\Models\Concerns\BelongsToAdminTenant} 全局作用域，控制台与 API 须继续走 *Owned 服务层过滤。
     */
    protected static function booted(): void
    {
        static::saved(function (self $cert) {
            if (! $cert->wasChanged(['domain_name', 'certificate', 'private_key', 'domain_id'])) {
                return;
            }

            $cert->loadMissing('domain');
            app(CertificateDeployService::class)->afterCertMaterialOrHostChange($cert);
        });
    }

    public const STATUS_NONE = 'none';

    public const STATUS_PENDING_DNS = 'pending_dns';

    public const STATUS_VALIDATING = 'validating';

    public const STATUS_ISSUED = 'issued';

    public const STATUS_DEPLOYING = 'deploying';

    public const STATUS_ACTIVE = 'active';

    public const STATUS_FAILED = 'failed';

    /**
     * 续期 cron 可入队的状态：进行中 validating 仅在超过卡住阈值后重试。
     */
    public function scopeRenewalDue($query, \DateTimeInterface $expiresBefore, int $validatingStuckHours = 3)
    {
        $stuckBefore = now()->subHours(max(1, $validatingStuckHours));

        return $query
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', $expiresBefore)
            ->where(function ($statusQuery) use ($stuckBefore) {
                $statusQuery->whereIn('status', [
                    self::STATUS_ACTIVE,
                    self::STATUS_ISSUED,
                    self::STATUS_DEPLOYING,
                    self::STATUS_FAILED,
                ])->orWhere(function ($inner) use ($stuckBefore) {
                    $inner->where('status', self::STATUS_VALIDATING)
                        ->where('updated_at', '<=', $stuckBefore);
                });
            });
    }

    protected $table = 'redi_domain_certs';

    protected $guarded = [
        'certificate',
        'private_key',
        'admin_id',
    ];

    protected $fillable = [
        'domain_id',
        'domain_name',
        'status',
        'method',
        'expires_at',
        'last_error',
        'last_error_code',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
    ];

    public function domain()
    {
        return $this->belongsTo(RediAdminDomain::class, 'domain_id');
    }

    public function deployments()
    {
        return $this->hasMany(RediCertDeployment::class, 'cert_id');
    }

    public function setCertificatePem(string $pem): void
    {
        $this->certificate = Crypt::encryptString($pem);
    }

    public function getCertificatePem(): ?string
    {
        if (! $this->certificate) {
            return null;
        }

        try {
            return Crypt::decryptString($this->certificate);
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function storedCredentialsUnreadable(): bool
    {
        if ($this->certificate && $this->getCertificatePem() === null) {
            return true;
        }
        if ($this->private_key && $this->getPrivateKeyPem() === null) {
            return true;
        }

        return false;
    }

    /** 解密失败时写入 last_error 并记日志（供节点拉取证书路径调用）。 */
    public function flagCredentialUnreadableIfNeeded(): void
    {
        if (! $this->storedCredentialsUnreadable()) {
            return;
        }
        if (RediCertLastError::matches($this, RediCertLastError::CREDENTIAL_UNREADABLE)) {
            return;
        }
        RediCertLastError::apply($this, RediCertLastError::CREDENTIAL_UNREADABLE);
        $this->saveQuietly();
        Log::warning('redi_domain_cert credential decrypt failed', ['cert_id' => $this->id]);
        $this->loadMissing('domain');
        app(CertificateDeployService::class)->afterCertMaterialOrHostChange($this);
    }

    public function setPrivateKeyPem(string $pem): void
    {
        $this->private_key = Crypt::encryptString($pem);
    }

    public function getPrivateKeyPem(): ?string
    {
        if (! $this->private_key) {
            return null;
        }

        try {
            return Crypt::decryptString($this->private_key);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** 节点 `certificates_revision`：密文 PEM 指纹（不含明文，避免哈希泄露证书内容）。 */
    public function credentialCiphertextFingerprint(): string
    {
        return sha1((string) $this->certificate."\0".(string) $this->private_key);
    }

    public function statusLabel(): string
    {
        $key = 'redi-admin-domain.options.cert_status.'.$this->status;
        $label = __($key);

        return $label !== $key ? $label : (string) $this->status;
    }
}
