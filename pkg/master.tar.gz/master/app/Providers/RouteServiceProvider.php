<?php

namespace App\Providers;

use App\Support\OpsDisplaySanitizer;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/home';

    /**
     * The controller namespace for the application.
     *
     * When present, controller route declarations will automatically be prefixed with this namespace.
     *
     * @var string|null
     */
    // protected $namespace = 'App\\Http\\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::prefix('api')
                ->middleware('api')
                ->namespace($this->namespace)
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->namespace($this->namespace)
                ->group(base_path('routes/web.php'));
        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            if ($request->is('api/nodes/*')) {
                return Limit::none();
            }

            return Limit::perMinute(60)->by(optional($request->user())->id ?: $this->throttleIpKey($request));
        });

        RateLimiter::for('redi-node', function (Request $request) {
            $node = $request->attributes->get('redi_node');
            $token = $request->bearerToken();
            if ($token !== null && OpsDisplaySanitizer::containsControlChars($token)) {
                $token = null;
            }
            $key = $node ? 'node:'.$node->id : ($token ?: $this->throttleIpKey($request));

            if ($request->is('api/nodes/certificates')) {
                return Limit::perMinute(30)->by($key);
            }

            return Limit::perMinute(300)->by($key);
        });
    }

    protected function throttleIpKey(Request $request): string
    {
        $ip = (string) $request->ip();
        if ($ip === '' || OpsDisplaySanitizer::containsControlChars($ip)) {
            return 'invalid-ip';
        }

        return $ip;
    }
}
