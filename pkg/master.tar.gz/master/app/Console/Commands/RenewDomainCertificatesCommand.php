<?php

namespace App\Console\Commands;

use App\Jobs\IssueDomainCertificateJob;
use App\Models\RediDomainCert;
use App\Services\CertificateDeployService;
use App\Services\DomainRecordNormalizer;
use App\Support\HostNameValidator;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class RenewDomainCertificatesCommand extends Command
{
    protected $signature = 'redi:renew-certificates
                            {--days=25 : Queue renewal within this many days before expiry}
                            {--dry-run : List domains only; do not enqueue}';

    protected $description = 'Queue renewal for domain certificates expiring soon (HTTP-01)';

    public function handle(): int
    {
        $days = min(365, max(1, (int) $this->option('days')));
        $dryRun = (bool) $this->option('dry-run');
        $deadline = now()->addDays($days);

        $validatingStuckHours = max(1, (int) config('redi.renew_validating_stuck_hours', 3));

        $certs = RediDomainCert::query()
            ->with('domain')
            ->renewalDue($deadline, $validatingStuckHours)
            ->whereHas('domain', function ($query) {
                $query->where('status', 1);
            })
            ->orderBy('expires_at')
            ->get();

        $queued = 0;
        $i = 0;
        foreach ($certs as $cert) {
            if ($dryRun) {
                $host = DomainRecordNormalizer::originalUrlIfValid(
                    (string) optional($cert->domain)->original_url ?? ''
                );
                if ($host === '') {
                    $this->warn('Skipping invalid hostname cert #'.$cert->id);
                    continue;
                }
            } else {
                $fresh = CertificateDeployService::freshCertWithPersistedRealign($cert);
                if (! $fresh || ! DomainRecordNormalizer::certMatchesAdminDomain($fresh)) {
                    Log::warning('redi:renew-certificates skip invalid domain original_url', [
                        'cert_id' => $cert->id,
                        'domain_id' => $cert->domain_id,
                    ]);
                    $this->warn('Skipping invalid hostname cert #'.$cert->id);
                    continue;
                }
                $cert = $fresh;
                $host = HostNameValidator::toCanonicalAscii((string) $cert->domain_name);
            }

            if ($dryRun) {
                $this->line(sprintf(
                    '[dry-run] %s expires %s status=%s',
                    $host,
                    $cert->expires_at->format('Y-m-d H:i'),
                    $cert->status
                ));
                $queued++;
                continue;
            }

            IssueDomainCertificateJob::dispatch((int) $cert->domain_id)
                ->delay(now()->addSeconds($i * 20));
            $this->info('Queued renew for '.$host);
            $i++;
            $queued++;
        }

        $summary = sprintf(
            'redi:renew-certificates %s: %d cert(s) within %d days',
            $dryRun ? 'dry-run' : 'queued',
            $queued,
            $days
        );
        Log::info($summary);
        if ($queued === 0 && ! $dryRun) {
            $this->info('No certificates due for renewal。');
        } else {
            $this->info($summary);
        }

        return self::SUCCESS;
    }
}
