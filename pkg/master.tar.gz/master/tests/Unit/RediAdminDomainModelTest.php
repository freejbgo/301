<?php

namespace Tests\Unit;

use App\Models\RediAdminDomain;
use App\Models\RediDomainCert;
use App\Support\RediCertLastError;
use App\Support\RediErrorMessage;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class RediAdminDomainModelTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        config(['database.default' => 'sqlite']);
        config(['database.connections.sqlite' => [
            'driver' => 'sqlite',
            'database' => ':memory:',
            'prefix' => '',
        ]]);

        Schema::create('redi_acme_challenges', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('domain_name')->unique();
            $table->string('token');
            $table->text('response_body');
            $table->timestamp('expires_at');
            $table->timestamps();
        });

        Schema::create('redi_acme_challenge_node_sync', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('node_id');
            $table->string('domain_name');
            $table->timestamp('synced_at')->nullable();
            $table->timestamps();
        });

        Schema::create('redi_admin_domain', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('group_id')->default(1);
            $table->unsignedInteger('admin_id')->default(1);
            $table->string('admin_name')->nullable();
            $table->string('original_url');
            $table->string('original_url_hash', 64)->nullable();
            $table->string('skip_url');
            $table->unsignedTinyInteger('status')->default(1);
            $table->unsignedInteger('skip_num')->default(0);
            $table->boolean('force_https')->default(false);
            $table->timestamps();
        });

        Schema::create('redi_domain_certs', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('domain_id');
            $table->string('domain_name');
            $table->string('status')->default('none');
            $table->text('last_error')->nullable();
            $table->string('last_error_code')->nullable();
            $table->text('certificate')->nullable();
            $table->text('private_key')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });

        Schema::create('redi_nodes', function (Blueprint $table) {
            $table->increments('id');
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });

        Schema::create('redi_cert_deployments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('cert_id');
            $table->unsignedInteger('node_id');
            $table->string('status')->default('pending');
            $table->text('last_error')->nullable();
            $table->timestamp('deployed_at')->nullable();
            $table->timestamps();
        });
    }

    public function test_certificate_list_filter_none(): void
    {
        RediAdminDomain::query()->insert([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'a.com',
            'skip_url' => 'https://x.com',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $withCert = RediAdminDomain::query()->insertGetId([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'b.com',
            'skip_url' => 'https://x.com',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_domain_certs')->insert([
            'domain_id' => $withCert,
            'domain_name' => 'b.com',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $ids = RediAdminDomain::query()->tap(function ($q) {
            RediAdminDomain::applyCertificateListFilter($q, 'none');
        })->pluck('original_url')->all();

        $this->assertSame(['a.com'], $ids);
    }

    public function test_rejects_invalid_skip_url_on_save(): void
    {
        $domain = new RediAdminDomain();
        $domain->group_id = 1;
        $domain->admin_id = 1;
        $domain->original_url = 'valid.example';
        $domain->skip_url = 'javascript:alert(1)';

        $this->expectException(ValidationException::class);
        $domain->save();
    }

    public function test_normalizes_valid_skip_url(): void
    {
        $domain = new RediAdminDomain();
        $domain->group_id = 1;
        $domain->admin_id = 1;
        $domain->original_url = 'valid.example';
        $domain->skip_url = 'https://dest.example/path';

        $domain->save();

        $this->assertSame('https://dest.example/path', $domain->fresh()->skip_url);
    }

    public function test_disabling_domain_clears_acme_challenges(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'off.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        \DB::table('redi_acme_challenges')->insert([
            'domain_name' => 'off.example',
            'token' => 't',
            'response_body' => 'b',
            'expires_at' => now()->addHour(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_acme_challenge_node_sync')->insert([
            'node_id' => 1,
            'domain_name' => 'off.example',
            'synced_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 2;
        $domain->save();

        $this->assertSame(0, \DB::table('redi_acme_challenges')->count());
        $this->assertSame(0, \DB::table('redi_acme_challenge_node_sync')->count());
    }

    public function test_disabling_domain_clears_cert_deployments(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'off.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'off.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $nodeId = \DB::table('redi_nodes')->insertGetId([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $nodeId,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 2;
        $domain->save();

        $this->assertSame(0, \DB::table('redi_cert_deployments')->count());
        $this->assertSame(RediDomainCert::STATUS_ISSUED, RediDomainCert::query()->find($certId)->status);
        $this->assertStringContainsString('Domain disabled', (string) RediDomainCert::query()->find($certId)->last_error);
    }

    public function test_changing_original_url_prunes_non_pullable_deployments(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'was.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'was.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => null,
            'private_key' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $nodeId = \DB::table('redi_nodes')->insertGetId([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $nodeId,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->original_url = 'now.example';
        $domain->save();

        $this->assertSame(0, \DB::table('redi_cert_deployments')->count());
    }

    public function test_disabling_domain_sets_cancel_hint_on_failed_cert_with_deployments(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'failed-off.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'failed-off.example',
            'status' => RediDomainCert::STATUS_FAILED,
            'last_error' => 'All responding nodes failed',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $nodeId = \DB::table('redi_nodes')->insertGetId([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $nodeId,
            'status' => 'failed',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 2;
        $domain->save();

        $this->assertSame(
            RediErrorMessage::get(RediCertLastError::DOMAIN_DISABLED_CANCEL),
            RediDomainCert::query()->find($certId)->last_error
        );
        $this->assertSame(RediDomainCert::STATUS_FAILED, RediDomainCert::query()->find($certId)->status);
    }

    public function test_disabling_domain_sets_cancel_hint_on_issued_cert_with_pending_deployments(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'issued-off.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'issued-off.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'last_error' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $nodeId = \DB::table('redi_nodes')->insertGetId([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $nodeId,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 2;
        $domain->save();

        $this->assertSame(
            RediErrorMessage::get(RediCertLastError::DOMAIN_DISABLED_CANCEL),
            RediDomainCert::query()->find($certId)->last_error
        );
        $this->assertSame(RediDomainCert::STATUS_ISSUED, RediDomainCert::query()->find($certId)->status);
    }

    public function test_reenabling_domain_clears_disable_deploy_cancel_message(): void
    {
        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'back.example',
            'skip_url' => 'https://dest.example/',
            'status' => 2,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'back.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'last_error' => RediErrorMessage::get(RediCertLastError::DOMAIN_DISABLED_CANCEL),
            'last_error_code' => RediCertLastError::DOMAIN_DISABLED_CANCEL,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 1;
        $domain->save();

        $this->assertNull(RediDomainCert::query()->find($certId)->last_error);
    }

    public function test_reenabling_domain_queues_deploy_when_cert_is_eligible(): void
    {
        \DB::table('redi_nodes')->insert([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'back.example',
            'skip_url' => 'https://dest.example/',
            'status' => 2,
        ]);

        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domain->id,
            'domain_name' => 'back.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain->status = 1;
        $domain->save();

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $certId,
            'status' => 'pending',
        ]);
    }

    public function test_new_enabled_domain_does_not_auto_queue_deploy_without_disable_transition(): void
    {
        \DB::table('redi_nodes')->insert([
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $domain = RediAdminDomain::create([
            'group_id' => 1,
            'admin_id' => 1,
            'original_url' => 'new.example',
            'skip_url' => 'https://dest.example/',
            'status' => 1,
        ]);

        \DB::table('redi_domain_certs')->insert([
            'domain_id' => $domain->id,
            'domain_name' => 'new.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }
}
