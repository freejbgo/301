<?php

namespace Tests\Unit;

use App\Models\RediDomainCert;
use App\Models\RediNode;
use App\Services\CertificateDeployService;
use App\Support\RediErrorMessage;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class CertificateDeployServiceTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        config(['database.default' => 'sqlite']);
        config(['database.connections.sqlite' => [
            'driver' => 'sqlite',
            'database' => ':memory:',
            'prefix' => '',
        ]]);

        Schema::create('redi_nodes', function (Blueprint $table) {
            $table->increments('id');
            $table->boolean('enabled')->default(true);
            $table->string('public_ip', 45)->nullable();
            $table->timestamp('last_heartbeat_at')->nullable();
            $table->timestamps();
        });

        Schema::create('redi_admin_domain', function (Blueprint $table) {
            $table->increments('id');
            $table->string('original_url');
            $table->unsignedTinyInteger('status')->default(1);
            $table->timestamps();
        });

        Schema::create('redi_domain_certs', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('domain_id');
            $table->string('domain_name');
            $table->text('certificate')->nullable();
            $table->text('private_key')->nullable();
            $table->string('status')->default('active');
            $table->text('last_error')->nullable();
            $table->string('last_error_code')->nullable();
            $table->timestamps();
        });

        Schema::create('redi_cert_deployments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('cert_id');
            $table->unsignedInteger('node_id');
            $table->string('status')->default('pending');
            $table->text('last_error')->nullable();
            $table->timestamp('deployed_at')->nullable();
            $table->timestamps();
            $table->unique(['cert_id', 'node_id']);
        });
    }

    public function test_sync_deployments_realigns_stale_cert_domain_name(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => 'active',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertSame('edge.example', RediDomainCert::query()->find($certId)->domain_name);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_sync_deployments_reconciles_issued_to_deploying_for_live_node(): void
    {
        $node = RediNode::query()->create([
            'enabled' => true,
            'public_ip' => '1.2.3.4',
            'last_heartbeat_at' => now(),
        ]);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertSame(
            RediDomainCert::STATUS_DEPLOYING,
            RediDomainCert::query()->find($certId)->status
        );
    }

    public function test_sync_prunes_stale_ok_before_backfilling_pullable_cert(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $staleDomainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'stale.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $staleCertId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $staleDomainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => null,
            'private_key' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $staleCertId,
            'node_id' => $node->id,
            'status' => 'ok',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $goodDomainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'good.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $goodCertId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $goodDomainId,
            'domain_name' => 'good.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertDatabaseMissing('redi_cert_deployments', [
            'cert_id' => $staleCertId,
            'node_id' => $node->id,
        ]);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $goodCertId,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_sync_deployments_for_node_creates_pending_rows(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => 'active',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_cert_is_eligible_for_deploy_queue_does_not_persist_realign(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->with('domain')->find($certId);

        $this->assertTrue(CertificateDeployService::certIsEligibleForDeployQueue($cert));
        $this->assertSame('stale.example', RediDomainCert::query()->find($certId)->domain_name);
    }

    public function test_requeue_failed_deployments_realigns_cert_domain_name(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_FAILED,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'pem error',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);

        $this->assertSame('edge.example', $cert->fresh()->domain_name);
    }

    public function test_requeue_failed_deployments_prunes_ineligible_failed_rows(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_FAILED,
            'certificate' => null,
            'private_key' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'simulated',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $count = app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);

        $this->assertSame(0, $count);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_requeue_failed_deployments_resets_status(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_FAILED,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'pem error',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $count = app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);
        $this->assertSame(1, $count);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
        $cert->refresh();
        $this->assertSame(RediDomainCert::STATUS_DEPLOYING, $cert->status);
    }

    public function test_mark_node_ack_rejects_ok_when_admin_domain_invalid(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'not a valid host!!!',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'orphan.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $svc = app(CertificateDeployService::class);
        $this->assertTrue($svc->markNodeAck($cert, $node, true));

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
        ]);
        $deploymentError = (string) \DB::table('redi_cert_deployments')
            ->where('cert_id', $cert->id)
            ->where('node_id', $node->id)
            ->value('last_error');
        $this->assertStringContainsString(RediErrorMessage::get('cert.domain_mismatch_reject'), $deploymentError);
        $this->assertSame(RediDomainCert::STATUS_FAILED, $cert->fresh()->status);
    }

    public function test_mark_node_ack_rejects_ok_when_domain_disabled(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 2,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $svc = app(CertificateDeployService::class);
        $this->assertTrue($svc->markNodeAck($cert, $node, true));

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
        ]);
    }

    public function test_refresh_cert_status_does_not_mark_active_without_pullable_material(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'ok',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $method = new \ReflectionMethod(CertificateDeployService::class, 'refreshCertStatusFromDeployments');
        $method->setAccessible(true);
        $method->invoke(app(CertificateDeployService::class), $cert->fresh()->load('domain'));

        $this->assertSame(RediDomainCert::STATUS_ISSUED, $cert->fresh()->status);
        $this->assertStringContainsString(RediErrorMessage::get('cert.ack_not_deployable'), (string) $cert->fresh()->last_error);
    }

    public function test_refresh_cert_status_stays_deploying_when_enabled_node_still_pending(): void
    {
        $live = RediNode::query()->create([
            'enabled' => true,
            'public_ip' => '1.2.3.4',
            'last_heartbeat_at' => now(),
        ]);
        $cold = RediNode::query()->create([
            'enabled' => true,
            'public_ip' => '5.6.7.8',
            'last_heartbeat_at' => null,
        ]);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $live->id,
            'status' => 'ok',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $cold->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $method = new \ReflectionMethod(CertificateDeployService::class, 'refreshCertStatusFromDeployments');
        $method->setAccessible(true);
        $method->invoke(app(CertificateDeployService::class), $cert->fresh()->load('domain'));

        $this->assertSame(RediDomainCert::STATUS_DEPLOYING, $cert->fresh()->status);
    }

    public function test_mark_node_ack_is_idempotent_when_already_ok(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'ok',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $svc = app(CertificateDeployService::class);
        $this->assertTrue($svc->markNodeAck($cert, $node, true));
        $this->assertSame(RediDomainCert::STATUS_ACTIVE, $cert->fresh()->status);
    }

    public function test_sync_realigns_control_char_cert_domain_name_from_domain(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => "evil\x00.example",
            'status' => 'active',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertSame('edge.example', RediDomainCert::query()->find($certId)->domain_name);
        $this->assertDatabaseCount('redi_cert_deployments', 1);
    }

    public function test_sync_skips_certs_with_invalid_domain_name(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => '1.2.3.4',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_domain_certs')->insert([
            'domain_id' => $domainId,
            'domain_name' => '1.2.3.4',
            'status' => 'active',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->syncDeploymentsForNode($node);

        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_requeue_failed_deployments_skips_disabled_domain(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_FAILED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'failed',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $count = app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);

        $this->assertSame(0, $count);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_requeue_failed_deployments_skips_disabled_node(): void
    {
        $node = RediNode::query()->create(['enabled' => false, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_FAILED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'failed',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $count = app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);

        $this->assertSame(0, $count);
    }

    public function test_requeue_failed_deployments_skips_invalid_admin_domain(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'not a valid host!!!',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'orphan.example',
            'status' => RediDomainCert::STATUS_FAILED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'pem error',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $count = app(CertificateDeployService::class)->requeueFailedDeployments((int) $node->id, null);

        $this->assertSame(0, $count);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_queue_deploy_skips_without_pem_material(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
        ]);
        RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);

        $queued = app(CertificateDeployService::class)->queueDeploy($cert);

        $this->assertFalse($queued);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $this->assertStringContainsString('Certificate material unavailable', (string) $cert->fresh()->last_error);
        $this->assertSame(RediDomainCert::STATUS_ISSUED, $cert->fresh()->status);
    }

    public function test_queue_deploy_with_no_enabled_nodes_clears_stale_deployment_rows(): void
    {
        $node = RediNode::query()->create(['enabled' => false, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $queued = app(CertificateDeployService::class)->queueDeploy($cert->fresh());

        $this->assertTrue($queued);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $this->assertSame(RediDomainCert::STATUS_DEPLOYING, $cert->fresh()->status);
        $this->assertStringContainsString('No enabled nodes', (string) $cert->fresh()->last_error);
    }

    public function test_queue_deploy_skips_when_domain_disabled(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);

        $queued = app(CertificateDeployService::class)->queueDeploy($cert->fresh());

        $this->assertFalse($queued);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $this->assertStringContainsString('Domain disabled', (string) $cert->fresh()->last_error);
    }

    public function test_mark_node_ack_updates_last_error_when_deployment_already_failed(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $peer = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.5']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            [
                'cert_id' => $cert->id,
                'node_id' => $node->id,
                'status' => 'failed',
                'last_error' => 'first',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cert_id' => $cert->id,
                'node_id' => $peer->id,
                'status' => 'pending',
                'last_error' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        $svc = app(CertificateDeployService::class);
        $this->assertTrue($svc->markNodeAck($cert->fresh(), $node, false, 'second failure'));

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'second failure',
        ]);
    }

    public function test_mark_node_ack_clears_stale_last_error_when_deployment_already_ok(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'ok',
            'last_error' => 'stale',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->assertTrue(app(CertificateDeployService::class)->markNodeAck($cert->fresh(), $node, true));

        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'ok',
            'last_error' => null,
        ]);
    }

    public function test_mark_node_ack_rejects_disabled_node(): void
    {
        $node = RediNode::query()->create(['enabled' => false, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $applied = app(CertificateDeployService::class)->markNodeAck($cert, $node, true);

        $this->assertFalse($applied);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_queue_deploy_skips_when_cert_does_not_match_admin_domain(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'not a valid host!!!',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'orphan.example',
            'status' => 'issued',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $nodeId = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4'])->id;
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $nodeId,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $cert = RediDomainCert::query()->find($certId);
        $queued = app(CertificateDeployService::class)->queueDeploy($cert);

        $this->assertFalse($queued);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $this->assertStringContainsString(RediErrorMessage::get('cert.hostname_mismatch_skip'), (string) $cert->fresh()->last_error);
        $this->assertSame('issued', $cert->fresh()->status);
    }

    public function test_fresh_cert_with_persisted_realign_updates_stale_domain_name(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_ISSUED,
        ]);

        $fresh = CertificateDeployService::freshCertWithPersistedRealign($cert);

        $this->assertNotNull($fresh);
        $this->assertSame('edge.example', $fresh->domain_name);
        $this->assertSame('edge.example', RediDomainCert::query()->find($cert->id)->domain_name);
    }

    public function test_cert_is_node_pullable_does_not_persist_realign(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->with('domain')->find($certId);

        $this->assertTrue(CertificateDeployService::certIsNodePullable($cert));
        $this->assertSame('stale.example', RediDomainCert::query()->find($certId)->domain_name);
    }

    public function test_cert_is_node_pullable_requires_pem_domain_match_and_status(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $this->assertFalse(CertificateDeployService::certIsNodePullable($cert));

        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        $this->assertTrue(CertificateDeployService::certIsNodePullable($cert->fresh()));

        \DB::table('redi_admin_domain')->where('id', $domainId)->update(['status' => 0]);
        $this->assertFalse(CertificateDeployService::certIsNodePullable($cert->fresh()));
    }

    public function test_count_actionable_deployments_excludes_non_pullable_certs(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'failed',
            'last_error' => 'simulated',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->assertSame(0, CertificateDeployService::countActionableDeployments('failed'));
        $this->assertSame(0, CertificateDeployService::countActionableDeployments('pending'));
    }

    public function test_cert_save_without_pem_reconciles_active_status_down(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'ok',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $cert->certificate = null;
        $cert->private_key = null;
        $cert->save();

        $fresh = $cert->fresh();
        $this->assertSame(RediDomainCert::STATUS_ISSUED, $fresh->status);
        $this->assertNotSame(RediDomainCert::STATUS_ACTIVE, $fresh->status);
        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_cert_save_without_pem_prunes_pending_deployments(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $cert->id,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $cert->certificate = null;
        $cert->private_key = null;
        $cert->save();

        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_prune_stale_deployments_for_node_drops_non_pullable_ok_row(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => null,
            'private_key' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'ok',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->pruneStaleDeploymentsForNode($node);

        $this->assertDatabaseCount('redi_cert_deployments', 0);
    }

    public function test_prune_stale_deployments_for_node_drops_non_pullable_pending(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_DEPLOYING,
            'last_error' => 'Waiting for nodes to pull certificate',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->pruneStaleDeploymentsForNode($node);

        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $this->assertSame(
            RediDomainCert::STATUS_ISSUED,
            RediDomainCert::query()->find($certId)->status
        );
    }

    public function test_handle_domain_reenabled_from_disabled_realigns_stale_domain_name_before_queue(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $domain = \App\Models\RediAdminDomain::query()->find($domainId);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'stale.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        app(CertificateDeployService::class)->handleDomainReenabledFromDisabled($domain);

        $this->assertSame('edge.example', RediDomainCert::query()->find($certId)->domain_name);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_handle_domain_reenabled_from_disabled_queues_eligible_cert(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ISSUED,
            'last_error' => \App\Support\RediErrorMessage::get(\App\Support\RediCertLastError::DOMAIN_DISABLED_CANCEL),
            'last_error_code' => \App\Support\RediCertLastError::DOMAIN_DISABLED_CANCEL,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $domain = \App\Models\RediAdminDomain::query()->find($domainId);

        app(CertificateDeployService::class)->handleDomainReenabledFromDisabled($domain);

        $fresh = RediDomainCert::query()->find($certId);
        $this->assertNull($fresh->last_error);
        $this->assertNull($fresh->last_error_code);
        $this->assertSame(RediDomainCert::STATUS_DEPLOYING, $fresh->status);
        $this->assertDatabaseHas('redi_cert_deployments', [
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
        ]);
    }

    public function test_disabling_node_deletes_its_cert_deployments(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => 'deploying',
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $node->enabled = false;
        $node->save();

        $this->assertDatabaseCount('redi_cert_deployments', 0);
        $fresh = RediDomainCert::query()->find($certId);
        $this->assertSame(RediDomainCert::STATUS_ISSUED, $fresh->status);
        $this->assertSame(
            \App\Support\RediErrorMessage::get(\App\Support\RediCertLastError::NODE_DISABLED_CLEARED),
            $fresh->last_error
        );
    }

    public function test_reconcile_demotes_active_cert_with_no_deployment_rows(): void
    {
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $cert = RediDomainCert::query()->create([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
        ]);
        $cert->setCertificatePem("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----");
        $cert->setPrivateKeyPem("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----");
        $cert->save();

        app(CertificateDeployService::class)->reconcileCertDeployStatus($cert->fresh());

        $this->assertSame(RediDomainCert::STATUS_ISSUED, $cert->fresh()->status);
    }

    public function test_disabling_one_node_keeps_active_cert_when_other_node_still_ok(): void
    {
        $nodeA = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $nodeB = RediNode::query()->create(['enabled' => true, 'public_ip' => '5.6.7.8']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            [
                'cert_id' => $certId,
                'node_id' => $nodeA->id,
                'status' => 'ok',
                'deployed_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cert_id' => $certId,
                'node_id' => $nodeB->id,
                'status' => 'ok',
                'deployed_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        $nodeA->enabled = false;
        $nodeA->save();

        $fresh = RediDomainCert::query()->find($certId);
        $this->assertSame(RediDomainCert::STATUS_ACTIVE, $fresh->status);
        $this->assertDatabaseCount('redi_cert_deployments', 1);
    }

    public function test_disabling_node_reconciles_active_cert_when_last_ok_row_removed(): void
    {
        $node = RediNode::query()->create(['enabled' => true, 'public_ip' => '1.2.3.4']);
        $domainId = \DB::table('redi_admin_domain')->insertGetId([
            'original_url' => 'edge.example',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $certId = \DB::table('redi_domain_certs')->insertGetId([
            'domain_id' => $domainId,
            'domain_name' => 'edge.example',
            'status' => RediDomainCert::STATUS_ACTIVE,
            'certificate' => Crypt::encryptString("-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"),
            'private_key' => Crypt::encryptString("-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----"),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        \DB::table('redi_cert_deployments')->insert([
            'cert_id' => $certId,
            'node_id' => $node->id,
            'status' => 'ok',
            'deployed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $node->enabled = false;
        $node->save();

        $fresh = RediDomainCert::query()->find($certId);
        $this->assertSame(RediDomainCert::STATUS_ISSUED, $fresh->status);
        $this->assertSame(
            \App\Support\RediErrorMessage::get(\App\Support\RediCertLastError::NODE_DISABLED_CLEARED),
            $fresh->last_error
        );
    }

    public function test_forget_actionable_deployment_metrics_clears_request_cache(): void
    {
        $ref = new \ReflectionClass(CertificateDeployService::class);
        $prop = $ref->getProperty('actionableDeploymentStatusCounts');
        $prop->setAccessible(true);
        $prop->setValue(null, ['pending' => 99, 'failed' => 1]);

        CertificateDeployService::forgetActionableDeploymentMetrics();

        $this->assertNull($prop->getValue());
    }
}
